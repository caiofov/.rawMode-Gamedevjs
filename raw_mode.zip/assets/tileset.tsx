<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="tileset" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="img/tileset.png" width="144" height="128"/>
</tileset>
